﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//socket
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Net.NetworkInformation;

namespace socket_client
{
    public partial class Form1 : Form
    {

        //全局变量

        //客户端socket
        Socket client_socket = null;

        //保存已经保存的客户端线程
        private List<Thread> client_conn_thread_list;

        //方法封装
        Action<TextBox,string> Show_TextBox_Message;

        //创建一个定时器
        //定时接收socket服务器传来的信息
        System.Timers.Timer Tcp_Socket_Rec_Timer = new System.Timers.Timer();

        //各种标志位

        //连接按键状态改变标志
        byte TCP_LINK_STATE_CNT = 0;

        //TCP连接成功标志
        byte TCP_CONN_SUCCESS_FLAG = 0;

        //TCP连接失败次数统计标志
        byte TCP_CONN_FAILED_CNT = 0;

        //发送或是接收信息清除标志
        byte CLEAR_TX_FLAG = 0;
        byte CLEAR_RX_FLAG = 0;

        //tcp发送、接收次数计数
        int TCP_TX_CNT = 0;
        int TCP_RX_CNT = 0;

        //TCP接收成功标记
        byte TCP_REC_SUCCESS_FLAG = 0;

        //发送按键标记
        byte SEND_BUTTON_FLAG = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            button1.Enabled = false;

            button2.BackColor = Color.Green;

            button3.Text = "已清零";
            button4.Text = "已清零";

            textBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
            textBox6.Text = " ";
            textBox7.Text = " ";
            textBox8.Text = " ";
            textBox9.Text = " ";

            string[] get_ipaddr = get_local_addr();

            for (int i = 0; i < get_ipaddr.Length; i++)
            {
                comboBox1.Items.Add(get_ipaddr[i]);
            }

            comboBox1.SelectedIndex = 0;

            //在子线程中更新界面元素
            Show_TextBox_Message = delegate(TextBox show_textbox,string str_in)
            {
                Show_String(show_textbox, str_in);
            };

            client_conn_thread_list = new List<Thread>();

            Tcp_Socket_Rec_Timer.Enabled = false;

            Thread Tcp_Socket_Rec_Timer_thread = new Thread(Tcp_Socket_Rec_TimerMange);

            client_conn_thread_list.Add(Tcp_Socket_Rec_Timer_thread);//线程保存

            Tcp_Socket_Rec_Timer_thread.Start();

            //关闭跨线程检测
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        /*################################################################################################################界面开始*/

        //连接
        private void button2_Click(object sender, EventArgs e)
        {
            string datestring = " ";
            string str_in = "FFFFFF";

            TCP_LINK_STATE_CNT++;
            if (TCP_LINK_STATE_CNT % 2 != 0)//第一次
            {
                Create_Tcp_Socket(comboBox1, textBox2);

                if (TCP_CONN_SUCCESS_FLAG == 1)//成功连接
                {
                    TCP_CONN_SUCCESS_FLAG = 0;

                    button1.Enabled = true;//发送按键状态改变

                    button2.Text = "断开连接";//连接按键状态改变
                    button2.BackColor = Color.Red;
                    button1.BackColor = Color.Green;

                    comboBox1.Enabled = false;
                    textBox2.Enabled = false;

                    datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                    textBox9.Invoke(Show_TextBox_Message, textBox9, datestring);
                    textBox5.Invoke(Show_TextBox_Message, textBox5, " ");
                }
                else
                {
                    TCP_CONN_SUCCESS_FLAG = 0;
                    TCP_LINK_STATE_CNT = 0;
                    TCP_CONN_FAILED_CNT++;

                    button1.Enabled = false;
                    button1.BackColor = Color.Gray;

                    comboBox1.Enabled = true;
                    textBox2.Enabled = true;

                    textBox5.Invoke(Show_TextBox_Message, textBox5, " ");
                    textBox9.Invoke(Show_TextBox_Message, textBox9, " ");
                }
                
            }
            else
            { 
                try
                {
                    if (client_socket.Connected)
                    {
                        //发送数据
                        if (radioButton1.Checked)//hex
                        {
                            Tcp_Send_String_to_byte(str_in, client_socket);
                        }
                        else //string
                        {
                            Tcp_Send_String_To_Byte(str_in, client_socket);
                        }
                    }
                    else
                    {
                        Close_Tcp_Socket();
                    }
                }
                catch
                {
                    Close_Tcp_Socket();
                }

                Close_Tcp_Socket();

                TCP_LINK_STATE_CNT = 0;

                button1.Enabled = false;
                button2.Text = "连接";
                button2.BackColor = Color.Green;
                button1.BackColor = Color.Gray;

                comboBox1.Enabled = true;
                textBox2.Enabled = true;

                textBox6.Invoke(Show_TextBox_Message, textBox6, "主动与服务器断开连接!");

                datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                textBox5.Invoke(Show_TextBox_Message, textBox5, datestring);
                
            }
            if (TCP_CONN_FAILED_CNT == 3)//连接失败超3次 弹出错误提示
            {
                TCP_CONN_FAILED_CNT = 0;
                MessageBox.Show("连接服务器失败次数超限，请检查客户端及服务器的IP地址、端口号", "连接错误提示");
            }
            TCP_TX_CNT = 0;
            TCP_RX_CNT = 0;

        }

        //发送
        private void button1_Click(object sender, EventArgs e)
        {
            string str_in = " ";
            string datestring = " ";

            str_in = textBox4.Text.Trim(); //自动去空

            if (str_in.Contains(" "))
            {
                str_in = str_in.Replace(" ", "");
            }

            try
            {
                if (client_socket.Connected)
                {
                    //发送数据
                    if (radioButton1.Checked)//hex
                    {
                        Tcp_Send_String_to_byte(str_in, client_socket);
                    }
                    else //string
                    {
                        Tcp_Send_String_To_Byte(str_in, client_socket);
                    }
                }
                else
                {
                    Close_Tcp_Socket();
                }
            }
            catch
            {
                Close_Tcp_Socket();
            }
            if (SEND_BUTTON_FLAG == 1)
            {
                SEND_BUTTON_FLAG = 0;

                timer1.Start();//开始定时  

                TCP_TX_CNT++;

                if (TCP_TX_CNT != 0)//发送成功有数据 清零按键状态改变
                {
                    button3.Text = "可清零";
                }

                button1.Text = "已发送";
                button1.BackColor = Color.Red;

                datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                textBox7.Invoke(Show_TextBox_Message, textBox7, TCP_TX_CNT.ToString() + ", " + datestring);
            }
            else
            {
                SEND_BUTTON_FLAG = 0;
                timer1.Stop();

                button1.Text = "发送";
                button1.BackColor = Color.Green;
            }
        }

        //定时器 定时扫描按键状态
        private void timer1_Tick(object sender, EventArgs e)
        {
            if ((SEND_BUTTON_FLAG != 1) && (SEND_BUTTON_FLAG != 2))
            {
                timer1.Stop();
                button1.Text = "发送";
                button1.BackColor = Color.Green;
            }
        }

        //清除发送信息
        private void button3_Click(object sender, EventArgs e)
        {
            CLEAR_TX_FLAG++;
            if (CLEAR_TX_FLAG % 2 != 0)
            {
                if ((textBox4.Text != " ") && (textBox7.Text != " "))//存在数据
                {
                    TCP_TX_CNT = 0;

                    textBox4.Text = " ";
                    textBox7.Text = " ";

                    //信息提示
                    button3.Text = "已清零";
                }
                else//没有任何数据
                {
                }                
            }
            else//第一次按下
            {
                if ((textBox4.Text == " ") && (textBox7.Text == " "))//不存在数据
                {
                    //信息提示
                    button3.Text = "已清零";
                }
                else
                {
                }
                CLEAR_TX_FLAG = 0;
            }
        }

        //清除接收信息
        private void button4_Click(object sender, EventArgs e)
        {
            CLEAR_RX_FLAG++;
            if (CLEAR_RX_FLAG % 2 != 0)
            {
                if ((textBox3.Text != " ") && (textBox8.Text != " "))//存在数据
                {
                    TCP_RX_CNT = 0;

                    textBox3.Text = " ";
                    textBox8.Text = " ";

                    //信息提示
                    button4.Text = "已清零";
                }
                else//没有任何数据
                {
                }                 
            }
            else//第一次按下
            {
                if ((textBox3.Text == " ") && (textBox8.Text == " "))//不存在数据
                {
                    //信息提示
                    button4.Text = "已清零";
                }
                else
                {
                }
                CLEAR_RX_FLAG = 0;
            }
        }

        //关于软件
        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Socket_Client V1.7 软件会持续更新!\n 作者:廖玥英 \n 联系方式(QQ):1092003911 \n 完成日期:2018/10/12", "关于socket_client软件");
        }

        /*################################################################################################################界面结束*/

        /*##############################################################################################################其它程序开始*/

        //检测端口是否被占用
        public static bool PortInUse(int port)
        {
            bool inUse = false;
 
            IPGlobalProperties ipProperties = IPGlobalProperties.GetIPGlobalProperties();

            IPEndPoint[] ipEndPoints = ipProperties.GetActiveTcpListeners();
 
            foreach (IPEndPoint endPoint in ipEndPoints)
            {
                if (endPoint.Port == port)
                {
                    inUse = true;
                    break;
                }
            }
            return inUse;
        }

        private string[] get_local_addr()
        {
            string host_mame = " ";

            //获取主机名
            host_mame = Dns.GetHostName();

            //获取主机地址信息
            IPHostEntry ipHostEntry = Dns.GetHostEntry(host_mame);

            string[] get_ipaddr = new string[ipHostEntry.AddressList.Length];
            int i = 0;

            foreach (IPAddress ip_addr in ipHostEntry.AddressList)
            {
                get_ipaddr[i] = ip_addr.ToString();
                i++;
            }
            return get_ipaddr;
        }

        //关闭TCP连接
        public void Close_Tcp_Socket()
        {
            Tcp_Socket_Rec_Timer.Enabled = false;

            client_socket.Close();

            //关闭线程
            for (int i = 0; i < client_conn_thread_list.Count; i++)
            {
                client_conn_thread_list[i].Abort();
            }
        }

        //创建TCP
        public void Create_Tcp_Socket(ComboBox ip_combox, TextBox port_textbox)
        {
            string str_ip_addr = " ";
            int port_name = 0;
            bool port_state = false;

            if ((ip_combox.SelectedItem.ToString() != " ") && (port_textbox.Text != " "))//填写IP地址 端口号
            {
                str_ip_addr = ip_combox.SelectedItem.ToString();
                port_name = Convert.ToInt32(port_textbox.Text);//数据类型一定是 int 否则会出错

                port_state = PortInUse(port_name);

                //if (port_state == false)
                //{

                //}
                //else
                //{
                //    MessageBox.Show("端口以及被占用!,请重新选择端口", "端口错误提示");
                //    return;
                //}

                client_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPAddress ip = IPAddress.Parse(str_ip_addr);
                IPEndPoint point = new IPEndPoint(ip, port_name);
              
                //尝试连接
                try
                {
                    client_socket.Connect(point);

                    textBox6.Invoke(Show_TextBox_Message, textBox6, "客户端连接中。。。");
                }
                catch
                {
                    //关闭socket
                    Close_Tcp_Socket();
                }

                //判断是否已经连接上
                try
                {
                    if (client_socket.Connected == true)
                    {
                        textBox6.Invoke(Show_TextBox_Message, textBox6, "与服务器连接成功!!!");
                        Tcp_Socket_Rec_Timer.Enabled = true;
                        TCP_CONN_SUCCESS_FLAG = 1;
                    }
                    else
                    {
                        textBox6.Invoke(Show_TextBox_Message, textBox6, "与服务器连接失败!!!");
                        Tcp_Socket_Rec_Timer.Enabled = false;
                        TCP_CONN_SUCCESS_FLAG = 2;
                    }
                }
                catch
                {
                    textBox6.Invoke(Show_TextBox_Message, textBox6, "检测连接状态出错!");
                    TCP_CONN_SUCCESS_FLAG = 2;
                }
            }
            else
            {
                MessageBox.Show("请填写正确的IP地址以及端口号!!!","连接错误提示");
            }
        }

        //定时器事件
        void Tcp_Socket_Rec_TimerMange()
        {
            Tcp_Socket_Rec_Timer.Elapsed += new ElapsedEventHandler(Tcp_Recive_Deal);//定时事件的方法    
            Tcp_Socket_Rec_Timer.Interval = 100; 
        }

        //tcp接收程序 线程
        void Tcp_Recive_Deal(object sender, EventArgs e)
        {
            int temp_len = 0;
            string datestring = " ";

            byte i = 0, j = 0;

            byte[] check_string = new byte[6] { 0X46, 0X46, 0X46, 0X46, 0X46, 0X46 };
            byte[] check_hex = new byte[3] { 0XFF, 0XFF, 0XFF };

            byte[] get_data = new byte[1024];
            string[] temp_str = new string[1024];

            while (true)
            {
                try
                {
                    if (client_socket.Connected)
                    {
                        temp_len = client_socket.Receive(get_data);

                        if (temp_len == 0)//无数据
                        {
                            break;
                        }
                        else
                        {
                            TCP_REC_SUCCESS_FLAG = 1;
                            Show_Byte_To_String(get_data, temp_str, temp_len, textBox3);

                            i = Data_Compare(check_hex, get_data);
                            j = Data_Compare(check_string, get_data);

                            if ((i == 1) || (j == 1))
                            {
                                i = 0;
                                j = 0;
                                TCP_LINK_STATE_CNT = 0;

                                Close_Tcp_Socket();
                                
                                button1.Enabled = false;
                                button2.Text = "连接";
                                button2.BackColor = Color.Green;
                                button1.BackColor = Color.Gray;

                                comboBox1.Enabled = true;
                                textBox2.Enabled = true;

                                datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                                textBox5.Invoke(Show_TextBox_Message, textBox5, datestring);
                                textBox6.Invoke(Show_TextBox_Message, textBox6, "被动与服务器断开连接_REC");

                                break;
                            }
                            else
                            {

                            }   
                        }
                    }
                    else
                    {
                        Close_Tcp_Socket();
                        break;
                    }
                }
                catch
                {
                    //关闭socket
                    Close_Tcp_Socket();
                    break;
                }
                if (TCP_REC_SUCCESS_FLAG == 1)
                {
                    TCP_REC_SUCCESS_FLAG = 0;

                    TCP_RX_CNT++;

                    if (TCP_RX_CNT != 0)//接收有数据 清零按键状态改变
                    {
                        button4.Text = "可清零";
                    }

                    datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                    textBox8.Invoke(Show_TextBox_Message, textBox8, TCP_RX_CNT.ToString() + ", " + datestring);
                }
            }
        }

        /*##############################################################################################################其它程序结束*/

        /*################################################################################################################程序开始*/

        //获取当前时间
        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }

        public static DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));

            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        //字节数组转换成字符串数组并显示
        public void Show_Byte_To_String(byte[] byte_in, string[] str_out, int len_in, TextBox show_textbox)
        {
            if (byte_in.Length > 0)
            {
                //添加换行
                show_textbox.AppendText("\r\n");//解决第一行不对齐的 bug(暂时方式 找不到更合适的) 

                for (int i = 0; i < len_in; i++)
                {
                    //转换为大写十六进制字符串
                    str_out[i] = Convert.ToString(byte_in[i], 16).ToUpper();

                    //字符串显示
                    show_textbox.AppendText((str_out[i].Length == 1 ? ("0" + str_out[i]) : str_out[i]) + " ");
                }
            }
            else
            { }
        }

        //字符串数组转换成字节数组并显示
        public void Tcp_Send_String_To_Byte(string str_in, Socket tcp_socket)
        {
            if (str_in.Length > 0)
            {
                byte[] byte_out = new byte[str_in.Length];

                byte_out = System.Text.Encoding.UTF8.GetBytes(str_in);

                tcp_socket.Send(byte_out, 0, byte_out.Length, SocketFlags.None);

                //按键状态改变 定时器计时提示标志
                SEND_BUTTON_FLAG = 1;
            }
            else
            {
                //按键状态改变 定时器计时提示标志
                SEND_BUTTON_FLAG = 2;
            }
        }

        //发送字符串
        private void Tcp_Send_String_to_byte(string str_in, Socket tcp_socket)
        {
            int i = 0;
            int num_of_page = 0;
            int num_of_singe = 0;

            if (str_in.Length > 0)
            {
                try
                {
                    byte[] Send_Buff = new byte[str_in.Length];

                    num_of_page = str_in.Length / 2; //两个一组数据发送
                    num_of_singe = str_in.Length - (num_of_page * 2);//只剩下一个数据

                    if ((num_of_page == 0) && (num_of_singe > 0))//只发送一个数据
                    {
                        Send_Buff[0] = Convert.ToByte(str_in.Substring(0, 1), 16);

                        tcp_socket.Send(Send_Buff, 0, 1, SocketFlags.None);
                    }
                    else if ((num_of_page > 0) && (num_of_singe == 0))
                    {
                        for (i = 0; i < num_of_page; i++)//两个一组数据发送
                        {
                            Send_Buff[i] = Convert.ToByte(str_in.Substring(2 * i, 2), 16);
                        }
                        tcp_socket.Send(Send_Buff, 0, num_of_page, SocketFlags.None);
                    }
                    else
                    {
                        for (i = 0; i < num_of_page; i++)
                        {
                            Send_Buff[i] = Convert.ToByte(str_in.Substring(2 * i, 2), 16);
                        }

                        //余下的数据
                        Send_Buff[i++] = Convert.ToByte(str_in.Substring((2 * num_of_page), 1), 16);

                        tcp_socket.Send(Send_Buff, 0, num_of_page + num_of_singe, SocketFlags.None);
                    }

                    //按键状态改变 定时器计时提示标志
                    SEND_BUTTON_FLAG = 1;
                }
                catch
                {
                    //按键状态改变 定时器计时提示标志
                    SEND_BUTTON_FLAG = 2;
                }
            }
            else
            {
                //按键状态改变 定时器计时提示标志
                SEND_BUTTON_FLAG = 2;

                MessageBox.Show("请填写要发送的信息再点击发送!", "发送失败提示!");//修复无发送内容点击发送无提示 bug
            }
        }

        //显示字符串
        public void Show_String(TextBox show_textbox, string str_in)
        {
            //if ("".Equals(show_textbox.Text))
            //{
                show_textbox.Text = str_in;
            //}
            //else
            //{
            //    show_textbox.Text += str_in;
            //}
        }

        //数据比较 用于主动断开连接
        public byte Data_Compare(byte[] data_check, byte[] data_in)
        {
            int j = 0;
            for (int i = 0; i < data_check.Length; i++)
            {
                if (data_check[i] == data_in[j])
                {
                    j++;
                }
                else
                {
                    return 2;
                }
            }
            return 1;
        }

        /*################################################################################################################程序结束*/

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
