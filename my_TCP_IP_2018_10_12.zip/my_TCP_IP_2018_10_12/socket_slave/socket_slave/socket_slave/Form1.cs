﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//socket

using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Net.NetworkInformation;

namespace socket_slave
{
    public partial class Form1 : Form
    {
        //连接按键状态改变标志
        byte TCP_LINK_STATE_CNT = 0;

        //TCP连接成功标志
        byte TCP_CONN_SUCCESS_FLAG = 0;

        //发送或是接收信息清除标志
        byte CLEAR_TX_FLAG = 0;
        byte CLEAR_RX_FLAG = 0;

        //tcp发送、接收次数计数
        int TCP_TX_CNT = 0;
        int TCP_RX_CNT = 0;

        //发送按键标记
        byte SEND_BUTTON_FLAG = 0;

        //TCP接收成功标记
        byte TCP_REC_SUCCESS_FLAG = 0;

        //客户端上线计数
        byte CLIENT_ON_LINE_CNT = 0;

        //保存已经保存的客户端线程
        private List<Thread> client_conn_thread_list;
        //保存已经保存的客户端线程
        private List<Socket> client_conn_socket_list;

        //创建一个定时器
        //定时接收socket服务器传来的信息
        System.Timers.Timer Tcp_Socket_Rec_Timer = new System.Timers.Timer();

        //方法封装
        Action<TextBox, string> Show_TextBox_Message;

        Socket Tcp_Socket_Listen = null;
        Socket Tcp_Socket_Send = null; 

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;

            button1.BackColor = Color.Green;

            button3.Text = "已清零";
            button4.Text = "已清零";

            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox6.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
            textBox7.Text = " ";
            textBox8.Text = " ";

            string[] get_ipaddr = get_local_addr();

            for (int i = 0; i < get_ipaddr.Length; i++)
            {
                comboBox1.Items.Add(get_ipaddr[i]);
            }

            comboBox1.SelectedIndex = 1;

            //在子线程中更新界面元素
            Show_TextBox_Message = delegate(TextBox show_textbox, string str_in)
            {
                Show_String(show_textbox, str_in);
            };

            //client_conn_thread_list = new List<Thread>();
            //client_conn_socket_list = new List<Socket>();

            //Tcp_Socket_Rec_Timer.Enabled = false;

            //Thread Tcp_Socket_Rec_Timer_thread = new Thread(Tcp_Socket_Rec_TimerMange);

            //client_conn_thread_list.Add(Tcp_Socket_Rec_Timer_thread);//线程保存

            //Tcp_Socket_Rec_Timer_thread.Start();

            //关闭跨线程检测
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        /*################################################################################################################界面开始*/

        //连接
        private void button1_Click(object sender, EventArgs e)
        {
            string datestring = " ";
            string str_in = "FFFFFF";

            TCP_LINK_STATE_CNT++;
            if ((TCP_LINK_STATE_CNT % 2) != 0)
            {
                Create_Tcp_Socket(comboBox1,textBox9);
            }
            else
            {
                try
                {
                    if (Tcp_Socket_Send.Connected)
                    {
                        //发送数据
                        if (radioButton1.Checked)//hex
                        {
                            Tcp_Send_String_to_byte(str_in, Tcp_Socket_Send);
                        }
                        else //string
                        {
                            Tcp_Send_String_To_Byte(str_in, Tcp_Socket_Send);
                        }
                    }
                    else
                    {
                        Close_Tcp_Socket();
                    }
                }
                catch
                {
                    Close_Tcp_Socket();
                }

                TCP_LINK_STATE_CNT = 0;
                Close_Tcp_Socket();

                button2.Enabled = false;
                button1.Text = "连接";
                button1.BackColor = Color.Green;
                button2.BackColor = Color.Gray;

                comboBox1.Enabled = true;
                textBox9.Enabled = true;
                textBox1.Invoke(Show_TextBox_Message, textBox1, "主动与客户端断开连接!");

                datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                textBox8.Invoke(Show_TextBox_Message, textBox8, datestring);
            }
            TCP_TX_CNT = 0;
            TCP_RX_CNT = 0;
        }

        //发送
        private void button2_Click(object sender, EventArgs e)
        {
            string str_in = " ";
            string datestring = " ";

            str_in = textBox2.Text.Trim(); //自动去空

            if (str_in.Contains(" "))
            {
                str_in = str_in.Replace(" ", "");
            }

            try
            {
                if (Tcp_Socket_Send.Connected)
                {
                    //发送数据
                    if (radioButton1.Checked)//hex
                    {
                        Tcp_Send_String_to_byte(str_in, Tcp_Socket_Send);
                    }
                    else //string
                    {
                        Tcp_Send_String_To_Byte(str_in, Tcp_Socket_Send);
                    }
                }
                else
                {
                    Close_Tcp_Socket();
                }
            }
            catch
            {
                Close_Tcp_Socket();
            }

            if (SEND_BUTTON_FLAG == 1)
            {
                SEND_BUTTON_FLAG = 0;

                timer1.Start();//开始定时  

                TCP_TX_CNT++;

                if (TCP_TX_CNT != 0)//发送成功有数据 清零按键状态改变
                {
                    button4.Text = "可清零";
                }

                button2.Text = "已发送";
                button2.BackColor = Color.Red;

                datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                textBox4.Invoke(Show_TextBox_Message, textBox4, TCP_TX_CNT.ToString() + ", " + datestring);
            }
            else
            {
                SEND_BUTTON_FLAG = 0;
                timer1.Stop();

                button2.Text = "发送";
                button2.BackColor = Color.Green;
            }
        }

        //清除发送信息
        private void button4_Click(object sender, EventArgs e)
        {
            CLEAR_TX_FLAG++;
            if (CLEAR_TX_FLAG % 2 != 0)
            {
                if ((textBox4.Text != " ") && (textBox2.Text != " "))//存在数据
                {
                    TCP_TX_CNT = 0;

                    textBox4.Text = " ";
                    textBox2.Text = " ";

                    //信息提示
                    button4.Text = "已清零";
                }
                else//没有任何数据
                {
                }
            }
            else//第2次按下
            {
                if ((textBox4.Text == " ") && (textBox2.Text == " "))//不存在数据
                {
                    //信息提示
                    button4.Text = "已清零";
                }
                else
                {
                }
                CLEAR_TX_FLAG = 0;
            }
        }

        //清除接收信息
        private void button3_Click(object sender, EventArgs e)
        {
            CLEAR_RX_FLAG++;
            if (CLEAR_RX_FLAG % 2 != 0)
            {
                if ((textBox3.Text != " ") && (textBox5.Text != " "))//存在数据
                {
                    TCP_RX_CNT = 0;

                    textBox3.Text = " ";
                    textBox5.Text = " ";

                    //信息提示
                    button3.Text = "已清零";
                }
                else//没有任何数据
                {
                }
            }
            else//第2次按下
            {
                if ((textBox3.Text == " ") && (textBox5.Text == " "))//不存在数据
                {
                    //信息提示
                    button3.Text = "已清零";
                }
                else
                {
                }
                CLEAR_RX_FLAG = 0; 
            }
        }

        //关于软件
        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Socket_Server V1.7 软件会持续更新!\n 作者:廖玥英 \n 联系方式(QQ):1092003911 \n 完成日期:2018/10/12", "关于socket_server软件");
        }

        //定时器 定时扫描按键状态
        private void timer1_Tick(object sender, EventArgs e)
        {
            if ((SEND_BUTTON_FLAG != 1) && (SEND_BUTTON_FLAG != 2))
            {
                timer1.Stop();
                button2.Text = "发送";
                button2.BackColor = Color.Green;
            }
        }

        /*################################################################################################################界面结束*/

        /*##############################################################################################################其它程序开始*/

        //检测端口是否被占用
        public static bool PortInUse(int port)
        {
            bool inUse = false;

            IPGlobalProperties ipProperties = IPGlobalProperties.GetIPGlobalProperties();

            IPEndPoint[] ipEndPoints = ipProperties.GetActiveTcpListeners();

            foreach (IPEndPoint endPoint in ipEndPoints)
            {
                if (endPoint.Port == port)
                {
                    inUse = true;
                    break;
                }
            }
            return inUse;
        }

        private string[] get_local_addr()
        {
            string host_mame = " ";

            //获取主机名
            host_mame = Dns.GetHostName();

            //获取主机地址信息
            IPHostEntry ipHostEntry = Dns.GetHostEntry(host_mame);

            string[] get_ipaddr = new string[ipHostEntry.AddressList.Length];
            int i = 0;

            foreach (IPAddress ip_addr in ipHostEntry.AddressList)
            {
                get_ipaddr[i] = ip_addr.ToString();
                i++;
            }
            return get_ipaddr;
        }

        //关闭TCP连接
        public void Close_Tcp_Socket()
        {
            Tcp_Socket_Listen.Close();
            Tcp_Socket_Send.Close();

            CLIENT_ON_LINE_CNT = 0;
            textBox6.Invoke(Show_TextBox_Message, textBox6, CLIENT_ON_LINE_CNT.ToString());

            //客户端无法再次连接
            ////关闭线程
            //for (int i = 0; i < client_conn_thread_list.Count; i++)
            //{
            //    client_conn_thread_list[i].Abort();
            //}
        }

        public void Create_Tcp_Socket(ComboBox ip_combox, TextBox port_textbox)
        {
            int port_name = 0;
            bool port_state = false;

            if ((ip_combox.SelectedItem.ToString() != " ") && (port_textbox.Text != " "))//填写IP地址 端口号
            {
                try
                {
                    client_conn_thread_list = new List<Thread>();
                    client_conn_socket_list = new List<Socket>();

                    port_name = Convert.ToInt32(port_textbox.Text);

                    //if (port_state == false)//检测端口是否被占用
                    //{

                    //}
                    //else
                    //{
                    //    MessageBox.Show("端口以及被占用!,请重新选择端口", "端口错误提示");
                    //    return;
                    //}

                    IPAddress ip = IPAddress.Any;
                    IPEndPoint point = new IPEndPoint(ip, port_name);

                    Tcp_Socket_Listen = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    Tcp_Socket_Listen.Bind(point);
                    Tcp_Socket_Listen.Listen(0);

                    textBox1.Invoke(Show_TextBox_Message, textBox1, "开始监听!");
                    button1.Text = "监听中";//连接按键状态改变
                    button1.BackColor = Color.Goldenrod;

                    Thread Tcp_Socket_Listen_thread = new Thread(Tcp_Listen_Deal);

                    client_conn_thread_list.Add(Tcp_Socket_Listen_thread);//添加到列表

                    Tcp_Socket_Listen_thread.IsBackground = true;
                    Tcp_Socket_Listen_thread.Start(Tcp_Socket_Listen);
                }
                catch
                {
                
                }              
            }
            else
            {
                MessageBox.Show("请填写正确的IP地址以及端口号!!!", "连接错误提示");
            }
        }

        void Tcp_Listen_Deal(object o)
        {
            string datestring = " ";
            Socket socketWatch = o as Socket;

            while (true)
            {
                try
                {
                    Tcp_Socket_Send = socketWatch.Accept();
                    //Tcp_Socket_Rec_Timer.Enabled = true;

                    TCP_CONN_SUCCESS_FLAG = 1;

                    CLIENT_ON_LINE_CNT++;

                    comboBox3.Items.Add((Tcp_Socket_Send.RemoteEndPoint as IPEndPoint).Address);
                    comboBox4.Items.Add((Tcp_Socket_Send.RemoteEndPoint as IPEndPoint).Port);

                    textBox6.Invoke(Show_TextBox_Message, textBox6, CLIENT_ON_LINE_CNT.ToString());
                    textBox1.Invoke(Show_TextBox_Message, textBox1, "与客户端连接成功!");

                    Thread Tcp_Socket_Rec_thread = new Thread(Tcp_Socket_Rec_Deal);

                    client_conn_thread_list.Add(Tcp_Socket_Rec_thread);//添加到列表

                    Tcp_Socket_Rec_thread.IsBackground = true;
                    Tcp_Socket_Rec_thread.Start(Tcp_Socket_Send);
                }
                catch
                {
                    //Tcp_Socket_Rec_Timer.Enabled = false;
                    Close_Tcp_Socket();
                    break;
                }

                if (TCP_CONN_SUCCESS_FLAG == 1)//成功
                {
                    TCP_CONN_SUCCESS_FLAG = 0;

                    button2.Enabled = true;//发送按键状态改变

                    button1.Text = "断开连接";//连接按键状态改变
                    button1.BackColor = Color.Red;
                    button2.BackColor = Color.Green;

                    comboBox1.Enabled = false;
                    textBox9.Enabled = false;

                    datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                    textBox7.Invoke(Show_TextBox_Message, textBox7, datestring);
                    textBox8.Invoke(Show_TextBox_Message, textBox8, " ");

                }
                else//接入失败
                {
                    TCP_CONN_SUCCESS_FLAG = 0;
                }
            }
        }

        ////定时器事件
        //void Tcp_Socket_Rec_TimerMange()
        //{
        //    Tcp_Socket_Rec_Timer.Elapsed += new ElapsedEventHandler(Tcp_Socket_Rec_Deal);//定时事件的方法    
        //    Tcp_Socket_Rec_Timer.Interval = 100;
        //}

        void Tcp_Socket_Rec_Deal(object o)
        {
            int temp_len = 0;
            string datestring = " ";

            byte[] get_data = new byte[1024];
            string[] temp_str = new string[1024];

            byte i = 0, j = 0 ;

            byte[] check_string = new byte[6]{0X46,0X46,0X46,0X46,0X46,0X46};
            byte[] check_hex = new byte[3]{ 0XFF, 0XFF, 0XFF };

            Socket Tcp_Socket_Send = o as Socket;

            while (true)
            {
                try
                {
                    if (Tcp_Socket_Send.Connected)
                    {
                        temp_len = Tcp_Socket_Send.Receive(get_data);

                        if (temp_len == 0)//无数据
                        {
                            break;
                        }
                        else
                        {
                            TCP_REC_SUCCESS_FLAG = 1; 
                            Show_Byte_To_String(get_data, temp_str, temp_len, textBox3);

                            i = Data_Compare(check_hex, get_data);
                            j = Data_Compare(check_string, get_data);

                            if ((i == 1) || (j == 1))
                            {
                                i = 0;
                                j = 0;
                                TCP_LINK_STATE_CNT = 0;

                                Close_Tcp_Socket();

                                button2.Enabled = false;
                                button1.Text = "连接";
                                button1.BackColor = Color.Green;
                                button2.BackColor = Color.Gray;

                                comboBox1.Enabled = true;
                                textBox9.Enabled = true;

                                datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                                textBox8.Invoke(Show_TextBox_Message, textBox8, datestring);

                                textBox1.Invoke(Show_TextBox_Message, textBox1, "被动与客户端断开连接_REC!");
                                break;
                            }
                            else
                            { 
                            
                            }   
                        }
                    }
                    else
                    {
                        Close_Tcp_Socket();
                        break;
                    }
                }
                catch
                {
                    Close_Tcp_Socket();
                    break;
                }

                if (TCP_REC_SUCCESS_FLAG == 1)
                {
                    TCP_REC_SUCCESS_FLAG = 0;

                    TCP_RX_CNT++;

                    if (TCP_RX_CNT != 0)//接收有数据 清零按键状态改变
                    {
                        button3.Text = "可清零";
                    }

                    datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                    textBox5.Invoke(Show_TextBox_Message, textBox5, TCP_RX_CNT.ToString() + ", " + datestring);
                }
            }
        }

        /*##############################################################################################################其它程序结束*/

        /*################################################################################################################程序开始*/

        //获取当前时间
        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }

        public static DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));

            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        //字节数组转换成字符串数组并显示
        public void Show_Byte_To_String(byte[] byte_in, string[] str_out, int len_in, TextBox show_textbox)
        {
            if (byte_in.Length > 0)
            {
                //添加换行
                show_textbox.AppendText("\r\n");//解决第一行不对齐的 bug(暂时方式 找不到更合适的) 

                for (int i = 0; i < len_in; i++)
                {
                    //转换为大写十六进制字符串
                    str_out[i] = Convert.ToString(byte_in[i], 16).ToUpper();

                    //字符串显示
                    show_textbox.AppendText((str_out[i].Length == 1 ? ("0" + str_out[i]) : str_out[i]) + " ");
                }
            }
            else
            { }
        }

        //字符串数组转换成字节数组并显示
        public void Tcp_Send_String_To_Byte(string str_in, Socket tcp_socket)
        {
            if (str_in.Length > 0)
            {
                byte[] byte_out = new byte[str_in.Length];

                byte_out = System.Text.Encoding.UTF8.GetBytes(str_in);

                tcp_socket.Send(byte_out, 0, byte_out.Length, SocketFlags.None);

                //按键状态改变 定时器计时提示标志
                SEND_BUTTON_FLAG = 1;
            }
            else
            {
                //按键状态改变 定时器计时提示标志
                SEND_BUTTON_FLAG = 2;
            }
        }

        //发送字符串
        private void Tcp_Send_String_to_byte(string str_in, Socket tcp_socket)
        {
            int i = 0;
            int num_of_page = 0;
            int num_of_singe = 0;

            if (str_in.Length > 0)
            {
                try
                {
                    byte[] Send_Buff = new byte[str_in.Length];

                    num_of_page = str_in.Length / 2; //两个一组数据发送
                    num_of_singe = str_in.Length - (num_of_page * 2);//只剩下一个数据

                    if ((num_of_page == 0) && (num_of_singe > 0))//只发送一个数据
                    {
                        Send_Buff[0] = Convert.ToByte(str_in.Substring(0, 1), 16);

                        tcp_socket.Send(Send_Buff, 0, 1, SocketFlags.None);
                    }
                    else if ((num_of_page > 0) && (num_of_singe == 0))
                    {
                        for (i = 0; i < num_of_page; i++)//两个一组数据发送
                        {
                            Send_Buff[i] = Convert.ToByte(str_in.Substring(2 * i, 2), 16);
                        }
                        tcp_socket.Send(Send_Buff, 0, num_of_page, SocketFlags.None);
                    }
                    else
                    {
                        for (i = 0; i < num_of_page; i++)
                        {
                            Send_Buff[i] = Convert.ToByte(str_in.Substring(2 * i, 2), 16);
                        }

                        //余下的数据
                        Send_Buff[i++] = Convert.ToByte(str_in.Substring((2 * num_of_page), 1), 16);

                        tcp_socket.Send(Send_Buff, 0, num_of_page + num_of_singe, SocketFlags.None);
                    }

                    //按键状态改变 定时器计时提示标志
                    SEND_BUTTON_FLAG = 1;
                }
                catch
                {
                    //按键状态改变 定时器计时提示标志
                    SEND_BUTTON_FLAG = 2;
                }
            }
            else
            {    
                //按键状态改变 定时器计时提示标志
                SEND_BUTTON_FLAG = 2;
                MessageBox.Show("请填写要发送的信息再点击发送!", "发送失败提示!");//修复无发送内容点击发送无提示 bug
            }
        }

        //显示字符串
        public void Show_String(TextBox show_textbox, string str_in)
        {
            //if ("".Equals(show_textbox.Text))
            //{
            show_textbox.Text = str_in;
            //}
            //else
            //{
            //    show_textbox.Text += str_in;
            //}
        }

        //数据比较 用于主动断开连接
        public byte Data_Compare(byte[] data_check, byte[] data_in)
        {
            int j = 0;
            for (int i = 0; i < data_check.Length; i++)
            {
                if (data_check[i] == data_in[j])
                {
                    j++;
                }
                else
                {
                    return 2;
                }
            }
            return 1;
        }


        /*################################################################################################################程序结束*/

        /*################################################################################################################无关程序开始*/

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        /*################################################################################################################无关程序结束*/
    }
}
